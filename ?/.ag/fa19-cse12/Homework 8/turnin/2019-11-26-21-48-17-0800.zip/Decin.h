#ifndef DECIN_H
#define DECIN_H

/* DO NOT CHANGE:  This file is used in evaluation 
 * Changing function signatures will result in a 25% deduction.
 * */

long decin (void);

#endif
